<?php
namespace Admin\Controller;
use Common\Controller\BackendController;
class SetmealController extends BackendController {
    public function _initialize() {
        parent::_initialize();
    }
}