<?php
	return array(
		'admin_role_group_name_length' => '角色组名称长度应在1~20个字内！',
		'admin_role_group_remark_length' => '角色组描述长度应在100个字内！',
		'admin_role_group_null_error_mid' => '请选择所属权限组！',
		'admin_role_group_null_error_mids' => '请选择角色组权限！',
		'admin_role_group_enum_error_mid' => '请正确选择所属权限组！',
		'admin_role_group_enum_error_ordid' => '请正确填写排序！',
	);
?>