<?php
	return array(
		/*
			为空提示
		*/
		'category_major_null_error_categoryname' => '专业名不能为空！',
		/*
			长度提示	
		*/
		'category_major_length_error_categoryname' => '专业名称应在1~40个字内！',
	);
?>