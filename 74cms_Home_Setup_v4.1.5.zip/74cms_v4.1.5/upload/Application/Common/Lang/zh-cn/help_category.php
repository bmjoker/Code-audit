<?php 
return array(
	'help_category_null_error_categoryname'=> '分类名称不能为空！', 
	'help_category_length_error_categoryname' => '分类名称长度应在1~30个字之间！',
	'help_category_unique_category' => '分类名称已经存在！'
)		
?>