<?php
	return array(
		'article_property_null_error_categoryname' => '新闻属性名称不能为空！',
		'article_property_length_error_categoryname' => '新闻属性名称应在1~40个字内！',
	);
?>