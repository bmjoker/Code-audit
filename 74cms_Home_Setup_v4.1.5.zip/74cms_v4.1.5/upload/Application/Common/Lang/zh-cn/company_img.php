<?php 
return array(
		/*
		**为空提示
		*/
		'company_img_null_error_uid' => '公司UID不能为空！', 
		'company_img_null_error_company_id' => '公司id不能为空！', 
		'company_img_null_error_title' => '公司图片标题不能为空', 
		'company_img_null_error_img' => '公司图片不能为空！', 
		/*
		**数字提示
		*/
		'company_img_enum_error_uid' => '请填写正确的uid！', 
		'company_img_enum_error_company_id' => '请填写正确的公司id！', 

		'company_img_residence_length_error' => '企业风采备注长度应在30个字内！',
)
?>