<?php 
return array(
		/*
		**为空提示
		*/
		'help_null_error_parentid'=> '请选择帮助分类！',
		'help_null_error_title'=> '帮助标题不能为空！',
		'help_null_error_content'=> '帮助内容不能为空！',
)		
?>