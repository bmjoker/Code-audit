<?php 
return array(
		'explain_category_null_error_categoryname'=> '分类名称不能为空！', 
		'explain_category_length_error_categoryname' => '分类名称长度应在1~30个字之间！',
		'explain_category_unique_category' => '分类名称已经存在！'
)		
?>