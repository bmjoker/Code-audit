<?php 
return array(
		/*
		**为空提示
		*/
		'consultant_null_error_name' => '顾问名不能为空！', 
		'consultant_null_error_pic' => '顾问头像不能为空！', 
		'consultant_null_error_qq' => '顾问qq不能为空！', 
)	
?>