<?php
	return array(
		/*
			为空提示
		*/
		'category_null_error_c_name' => '分类名不能为空！',
		'category_null_error_c_alias' => '分类调用名能为空！',
		/*
			长度提示
		*/
		'category_length_error_c_name' => '分类名称应在1~60个字内！',
		'category_length_error_c_alias' => '分类调用名应在1~60个字内！！',
	);
?>