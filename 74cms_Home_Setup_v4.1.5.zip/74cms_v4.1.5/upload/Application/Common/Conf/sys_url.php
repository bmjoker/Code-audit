<?php
	return array (
		'/^jobfair\/(?!admin)(\w+)$/' => 'jobfair/index/:1',
		'/^mall\/(?!admin)(\w+)$/' => 'mall/index/:1',
	);
?>